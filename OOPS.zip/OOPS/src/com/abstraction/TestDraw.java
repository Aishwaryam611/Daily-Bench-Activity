package com.abstraction;


//Using interface: by third user  

public class TestDraw {

	public static void main(String args[]){  
		Draw d=new Circle(); 
		d.draw();  
		}
		}  
	

