package com.abstraction;

public abstract class Language {
	
	public void display() {
	    System.out.println("This is Java Language");
	  }
	}

