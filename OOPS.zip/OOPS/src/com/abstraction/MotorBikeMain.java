package com.abstraction;

class MotorBikeMain {

	public static void main(String[] args) {

		MountainBike m1 = new MountainBike();
		m1.brake();

		SportsBike s1 = new SportsBike();
		s1.brake();
	}
}
