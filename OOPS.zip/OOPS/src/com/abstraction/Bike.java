package com.abstraction;

abstract class Bike {

	abstract void run();  
	}  

	
	
	

