package com.inheritance;

 class SolarSystem_ISTypeRelationship {
	
	}
	class Earth extends SolarSystem_ISTypeRelationship {
	}
	class Mars extends SolarSystem_ISTypeRelationship {
	}
		


